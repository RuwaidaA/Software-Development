
python insert-unis.py
python insert-cities.py
python insert-city_data.py
